#include<iostream>
#include<string>
using namespace std;
class Queue {
public:
	string data;
	Queue* face;
	Queue* rear;
	Queue* next;
	string id;
	string name;
	Queue() {
		face = nullptr;
		rear = nullptr;
		next = nullptr;
	}
	Queue(string d) {
		data = d;
	}
	void enqueue();
	void dequeue();
	int if_Empty();
	void peek();
	void display();
	~Queue() {
		delete face;
		delete rear;
		delete next;
	}
};
int Queue::if_Empty() {
	if (face == nullptr && rear == nullptr) {
		return true;
	}
	return false;
}
void Queue::enqueue() {
	string i, n;
	cout << "Enter id of customer: ";
	cin >> i;
	cin.ignore();
	cout << "Enter name of customer: ";
	getline(cin, n);
	Queue* new_node = new Queue();
	new_node->name = n;
	new_node->id = i;
	if (if_Empty()) {
		face = rear = new_node;
	}
	else {
		rear->next = new_node;
		rear = new_node;
	}

}
void Queue::dequeue() {
	if (face == nullptr) {
		cout << "Queue is empty!\n";
	}
	else if (face == rear) {
		cout << "Name is: " << face->name << endl;
		cout << "ID is: " << face->id;
		face = rear = nullptr;
	}
	else {
		Queue* new_node = face;
		cout << "Name is: " << face->name << endl;
		cout << "ID is: " << face->id;
		face = face->next;
		delete new_node;
	}
}
void Queue::peek() {
	if (face == nullptr) {
		cout << "Queue is empty\n";
	}
	else {
		cout << "The next customer to dequeue is: ";
		cout << "Name is: " << face->name << endl;
		cout << "ID is: " << face->id;
	}
}
void Queue::display() {
	Queue* new_node;
	new_node = face;
	int c = 0;
	cout << "All customers data in Queue is : \n";
	if (face == nullptr) {
		cout << "Queue is Empty\n";
		return;
	}
	else if (face == rear) {

		cout << "Customer " << ++c << " data: \n";
		cout << "Name is: " << new_node->name << endl;
		cout << "ID is: " << new_node->id;
	}
	else {
		while (new_node != nullptr) {
			cout << "Customer " << c++ << "data: \n";
			cout << "Name is: " << new_node->name << endl;
			cout << "ID is: " << new_node->id;
			new_node = new_node->next;
		}

	}
}
int main() {
	Queue q;
	int choice = 1;
	while (choice != 0) {
		cout << "\nEnter what do you wanna do: ";
		cout << "\n1)Add Customer.\n2)Serve Customer.\n3)Next Customer.\n4)Check if Empty.\n5)Display Queue.\n0)End programme.\n";
		cin >> choice;
		cout << "\n____________________________________________________________\n";
		switch (choice) {
		case 1: {
			q.enqueue();
			break;
		}
		case 2: {
			q.dequeue();
			break;
		}case 3: {
			q.peek();
			break;
		}case 4: {
			if (q.if_Empty()) {
				cout << "Queue is empty.\n";
			}
			else {
				cout << "Queue is not empty.\n";
			}
			break;
		}case 5: {
			q.display();
			break;
		}case 0: {
			return 0;
			break;
		}default: {
			cout << "Invalid input choice\n";
		}
		}

		cout << "\n_______________________________________________________\n";
	}

	system("Pause");
	return 0;
}