#include<iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;
    int height;

    Node(int val) {
        data = val;
        left = right = NULL;
        height = 1;
    }
};

Node* root = NULL;
void show_menu();
Node* insert_node(Node* node, int data);
Node* delete_node(Node* root, int data);
int getHeight(Node* n);
int getBalance(Node* n);
Node* rotateRight(Node* y);
Node* rotateLeft(Node* x);
Node* minValueNode(Node* node);
void preorder(Node* root);
int count_nodes(Node* root);
int findMin(Node* root);
int findMax(Node* root);

int main() {
    int choice = 0, val;
    int arr[] = { 44,17,32,78,50,48,62,88,84,80,82,92 };
    for (int i = 0; i < 12; i++)
        root = insert_node(root, arr[i]);

    cout << "\nInitial Preorder Traversal:\n";
    preorder(root);
    cout << endl;

    while (choice != 6) {
        show_menu();
        cin >> choice;
        switch (choice) {
        case 1: {

            cout << "\nDeleting node 44 from tree...\n";
            root = delete_node(root, 44);
            cout << "Updated Preorder:\n";
            preorder(root);
            cout << endl;
            break;
        }
        case 2: {

            cout << "\nInserting nodes 84, 92, 75...\n";
            root = insert_node(root, 84);
            root = insert_node(root, 92);
            root = insert_node(root, 75);
            cout << "After Insertions, Preorder:\n";
            preorder(root);
            cout << endl;
            break;
        }
        case 3: {

            cout << "\nCounting total nodes in AVL Tree...\n";
            cout << "Total Nodes = " << count_nodes(root) << endl;
            break;
        }
        case 4: {
            cout << "\nFinding Min and Max Nodes...\n";
            cout << "Min Node = " << findMin(root) << endl;
            cout << "Max Node = " << findMax(root) << endl;
            break;
        }
        case 5: {

            cout << "\nSplitting tree into 2 smaller AVL trees (for visualization only)...\n";
            cout << "\nTree 1 Preorder:\n";
            Node* tree1 = NULL;
            tree1 = insert_node(tree1, 48);
            tree1 = insert_node(tree1, 17);
            tree1 = insert_node(tree1, 32);
            tree1 = insert_node(tree1, 62);
            tree1 = insert_node(tree1, 75);
            preorder(tree1);
            cout << "\nTree 2 Preorder:\n";
            Node* tree2 = NULL;
            tree2 = insert_node(tree2, 84);
            tree2 = insert_node(tree2, 78);
            tree2 = insert_node(tree2, 88);
            tree2 = insert_node(tree2, 80);
            tree2 = insert_node(tree2, 82);
            tree2 = insert_node(tree2, 92);
            preorder(tree2);
            cout << endl;
            break;
        }
        case 6: {

            cout << "\nExiting Program... Thank you!\n";
            break;
        }
        default:
            cout << "\nInvalid Choice! Try again.\n";
        }
    }
    return 0;
}

void show_menu() {
    cout << "\n--------------------------------------------\n";
    cout << "Choose an option:\n";
    cout << "1) Delete node '44'\n";
    cout << "2) Insert 84, 92, 75\n";
    cout << "3) Count total nodes\n";
    cout << "4) Find Min and Max Node\n";
    cout << "5) Make 2 AVL Trees\n";
    cout << "6) Exit\n";
    cout << "--------------------------------------------\n";
    cout << "Enter choice: ";
}

int getHeight(Node* n) {
    if (!n) return 0;
    return n->height;
}

int getBalance(Node* n) {
    if (!n) return 0;
    return getHeight(n->left) - getHeight(n->right);
}

Node* rotateRight(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;
    x->right = y;
    y->left = T2;
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
    return x;
}

Node* rotateLeft(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;
    y->left = x;
    x->right = T2;
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
    return y;
}

Node* insert_node(Node* node, int data) {
    if (!node)
        return new Node(data);

    if (data < node->data)
        node->left = insert_node(node->left, data);
    else if (data > node->data)
        node->right = insert_node(node->right, data);
    else
        return node; 

    node->height = 1 + max(getHeight(node->left), getHeight(node->right));
    int balance = getBalance(node);

    if (balance > 1 && data < node->left->data)
        return rotateRight(node);
    if (balance < -1 && data > node->right->data)
        return rotateLeft(node);
    if (balance > 1 && data > node->left->data) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    if (balance < -1 && data < node->right->data) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

Node* minValueNode(Node* node) {
    Node* current = node;
    while (current->left != NULL)
        current = current->left;
    return current;
}

Node* delete_node(Node* root, int data) {
    if (!root) {
        return root;
    }
    if (data < root->data)
        root->left = delete_node(root->left, data);
    else if (data > root->data)
        root->right = delete_node(root->right, data);
    else {
        if (!root->left || !root->right) {
            Node* temp = root->left ? root->left : root->right;
            if (!temp) {
                temp = root;
                root = NULL;
            }
            else
                *root = *temp;
            delete temp;
        }
        else {
            Node* temp = minValueNode(root->right);
            root->data = temp->data;
            root->right = delete_node(root->right, temp->data);
        }
    }
    if (!root) return root;
    root->height = 1 + max(getHeight(root->left), getHeight(root->right));
    int balance = getBalance(root);

    if (balance > 1 && getBalance(root->left) >= 0)
        return rotateRight(root);
    if (balance > 1 && getBalance(root->left) < 0) {
        root->left = rotateLeft(root->left);
        return rotateRight(root);
    }
    if (balance < -1 && getBalance(root->right) <= 0)
        return rotateLeft(root);
    if (balance < -1 && getBalance(root->right) > 0) {
        root->right = rotateRight(root->right);
        return rotateLeft(root);
    }

    return root;
}
void preorder(Node* root) {
    if (!root) return;
    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}
int count_nodes(Node* root) {
    if (!root) return 0;
    return 1 + count_nodes(root->left) + count_nodes(root->right);
}
int findMin(Node* root) {
    Node* curr = root;
    while (curr && curr->left)
        curr = curr->left;
    return curr ? curr->data : -1;
}
int findMax(Node* root) {
    Node* curr = root;
    while (curr && curr->right)
        curr = curr->right;
    return curr ? curr->data : -1;
}
