#include <iostream>
using namespace std;

class Graph {
private:
	int V;                 
	bool directed;        
	bool useMatrix;     

	int matrix[50][50];    
	int list[50][50];       
	int weightList[50][50]; 
	int listSize[50]; 

public:
	Graph(int vertices, bool isDirected, bool useMatrixRep) {
		V = vertices;
		directed = isDirected;
		useMatrix = useMatrixRep;

		for (int i = 0; i < V; i++) {
			listSize[i] = 0;
			for (int j = 0; j < V; j++) {
				matrix[i][j] = 0;
				list[i][j] = 0;
				weightList[i][j] = 0;
			}
		}
	}

	void addEdge(int u, int v, int w) {
		if (u < 0 || u >= V || v < 0 || v >= V) {
			cout << "Invalid vertex!\n";
			return;
		}

		if (useMatrix) {
			matrix[u][v] = w;
			if (!directed)
				matrix[v][u] = w;
		}
		else {
			list[u][listSize[u]] = v;
			weightList[u][listSize[u]] = w;
			listSize[u]++;

			if (!directed) {
				list[v][listSize[v]] = u;
				weightList[v][listSize[v]] = w;
				listSize[v]++;
			}
		}
	}

	void removeEdge(int u, int v) {
		if (u < 0 || u >= V || v < 0 || v >= V) {
			cout << "Invalid vertex!\n";
			return;
		}

		if (useMatrix) {
			matrix[u][v] = 0;
			if (!directed)
				matrix[v][u] = 0;
		}
		else {
			for (int i = 0; i < listSize[u]; i++) {
				if (list[u][i] == v) {
					for (int j = i; j < listSize[u] - 1; j++) {
						list[u][j] = list[u][j + 1];
						weightList[u][j] = weightList[u][j + 1];
					}
					listSize[u]--;
					break;
				}
			}

			if (!directed) {
				for (int i = 0; i < listSize[v]; i++) {
					if (list[v][i] == u) {
						for (int j = i; j < listSize[v] - 1; j++) {
							list[v][j] = list[v][j + 1];
							weightList[v][j] = weightList[v][j + 1];
						}
						listSize[v]--;
						break;
					}
				}
			}
		}
	}

	void displayGraph() {
		if (useMatrix) {
			cout << "\nAdjacency Matrix:\n";
			for (int i = 0; i < V; i++) {
				for (int j = 0; j < V; j++)
					cout << matrix[i][j] << " ";
				cout << endl;
			}
		}
		else {
			cout << "\nAdjacency List:\n";
			for (int i = 0; i < V; i++) {
				cout << i << ": ";
				for (int j = 0; j < listSize[i]; j++) {
					cout << "(" << list[i][j] << ", w=" << weightList[i][j] << ") ";
				}
				cout << endl;
			}
		}
	}
};

int main() {
	int V, repChoice, typeChoice;
	cout << "Enter number of vertices (1_50): ";
	cin >> V;

	cout << "Choose representation:\n1) Adjacency Matrix\n2) Adjacency List\nChoice: ";
	cin >> repChoice;

	cout << "Choose graph type:\n1) Directed\n2) Undirected\nChoice: ";
	cin >> typeChoice;

	Graph g(V, typeChoice == 1, repChoice == 1);

	int choice;
	do {
		cout << "\nMenu:\n";
		cout << "1) Add Edge\n";
		cout << "2) Remove Edge\n";
		cout << "3) Display Graph\n";
		cout << "4) Exit\n";
		cout << "Enter your choice: ";
		cin >> choice;

		switch (choice) {
		case 1: {
			int u, v, w;
			cout << "Enter u v weight: ";
			cin >> u >> v >> w;
			g.addEdge(u, v, w);
			break;
		}
		case 2: {
			int u, v;
			cout << "Enter u v to remove: ";
			cin >> u >> v;
			g.removeEdge(u, v);
			break;
		}
		case 3:
			g.displayGraph();
			break;
		case 4:
			cout << "Exiting...\n";
			break;
		default:
			cout << "Invalid choice! Try again.\n";
		}
	} while (choice != 4);
	system("Pause");
	return 0;
}
