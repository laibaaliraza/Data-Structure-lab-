#include<iostream>
#include<queue>
using namespace std;
class Node {
public:
	int data;
	Node* left;
	Node* right;
	Node() {}
	Node(int a) {
		data = a;
		left = nullptr;
		right = nullptr;
	}
	Node* create(int a);
	void invert(Node* node);
	void display(Node* temp_node);
};
Node* root;
static Node* create() {
	int data;
	cout << "Enter data to put in Tree(-1 for no node): ";
	cin >> data;
	if (data == -1) {
		return nullptr;
	}
	Node* new_node = new Node(data);
	cout << "\nEnter left child for: " << data;
	new_node->left = create();
	cout << "\nEnter right child for: " << data;
	new_node->right = create();
	return new_node;

}
void Node::invert(Node* root) {
	if (root == nullptr) {
		return;
	}
	Node* temp = root->left;
	root->left = root->right;
	root->right = temp;
	invert(root->left);
	invert(root->right);
}
void Node::display(Node* temp_node) {
	if (temp_node == nullptr) {
		return;
	}
	queue<Node*> q;
	q.push(temp_node);
	while (!q.empty()) {
		Node* crr = q.front();
		q.pop();
		cout << crr->data << " ";
		if (crr->left != nullptr) {
			q.push(crr->left);
		}
		if (crr->right != nullptr) {
			q.push(crr->right);
		}
	}
}
int main() {
	root = nullptr;
	Node n;
	root = create();
	cout << "\nleft and right node swapping\n";
	n.invert(root);
	cout << "\n--------------------Display after swappiing--------------------\n";
	n.display(root);
	cout << endl;
	system("Pause");
	return 0;
}