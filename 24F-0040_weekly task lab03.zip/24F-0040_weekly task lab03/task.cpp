#include<iostream>
using namespace std;
struct node{
    string data;
    struct node* next;
};
node* head=nullptr;
void array_to_list(string data[],int size){
    for(int i=0;i<size;i++){
    node* new_node=new node();
    new_node->data=data[i];
    new_node->next=nullptr;
    if(head==nullptr){
        head=new_node;
    }else{
        node* temp;
        temp=head;
        while(temp->next!=nullptr){
            temp=temp->next;
        }temp->next=new_node;
    }
    }
}
void show_moons(){
    node* temp2=head;
    if(temp2==nullptr){
        cout<<"This array has no data"<<endl;
    }else{
        while(temp2!=nullptr){
            cout<<temp2->data<<endl;
            temp2=temp2->next;
        }
    }

}
void clear_list(){
    while(head!=nullptr){
        node* temp=head;
        head=head->next;
        delete temp;
    }
}
int main(){
char choice1;
do{
    clear_list();
    //interactive options
    cout<<"------------------Input------------------"<<endl;
    cout<<"Enter whihich planet's information you wanna know: "<<endl;
    cout<<"1. Mercury"<<endl;
    cout<<"2. Venus"<<endl;
    cout<<"3. Earth"<<endl;
    cout<<"4. Mars"<<endl;
    cout<<"5. Jupiter"<<endl;
    cout<<"6. Saturn"<<endl;
    cout<<"7. Uranus"<<endl;
    cout<<"8. Neptune"<<endl;
    cout<<"9. Pluto"<<endl;
    int choice;
    cin>>choice;
    //arrays for planets
    string Mercury[1]={"no_moon"}, Venus[1]={"no_moon"},Earth[1]={"Luna"},Mars[2]={"phobos","deimos"},
             Jupiter[5]={"many_moons: ","Ganymede","Callisto","lo","Europa"},Saturn[3]={"has_most","Titan","Enceladus"},
             Uranus[4]={"27_moons: ","Titenia","Eubiron","etc"},Neptune[3]={"14_moons: ","Triton","Nereid"},Pluto[4]={"5_moons: ","Charon","Hydra","Nix "};

cout<<"------------------Output------------------"<<endl;
switch(choice){
        case 1:
           cout<<"Mucury has: "<<endl;
           array_to_list(Mercury,1);
           break;
        case 2:
           cout<<"Venus has: "<<endl;
           array_to_list(Venus,1);
            break;
        case 3:
           cout<<"Earth has: "<<endl;
           array_to_list(Earth,1);
            break;
        case 4:
           cout<<"Mars has: "<<endl;
           array_to_list(Mars,2);
            break;
        case 5:
           cout<<"Jupiter has: "<<endl;
           array_to_list(Jupiter,5);
            break;
        case 6:
           cout<<"Saturn has: "<<endl;
           array_to_list(Saturn,3);
            break;
        case 7:
           cout<<"Uranus has: "<<endl;
           array_to_list(Uranus,4);
            break;
        case 8:
           cout<<"Neptune has: "<<endl;
           array_to_list(Neptune,3);
            break;
        case 9:
           cout<<"Pluto has: "<<endl;
           array_to_list(Pluto,4);
            break;
        default:
           cout<<"Invalid Input"<<endl;
           break;
    }
    show_moons();
    cout<<"Do you wanna have another planet's information: (y/n)"<<endl;
    cin>>choice1;
}while(choice1=='y' || choice1=='Y');
}