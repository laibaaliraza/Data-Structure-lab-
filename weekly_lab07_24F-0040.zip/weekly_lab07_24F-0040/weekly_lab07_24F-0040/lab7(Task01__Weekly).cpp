#include<iostream>
#include<string>
using namespace std;
class Queue {
public:
	string data;
	Queue* face;
	Queue* rear;
	Queue* next;
	string id;
	string name;
	int arrival;
	int sizekb;
	int priority;
	int maxsize;
	int count;
	Queue() {
		face = nullptr;
		rear = nullptr;
		next = nullptr;
		count = 0;
		cout << "Enter buffer size: ";
		cin >> maxsize;
	}
	Queue(string d) {
		data = d;
	}
	void enqueue();
	void dequeue();
	int if_Empty();
	void peek();
	void display();
	~Queue() {
		delete face;
		delete rear;
		delete next;
	}
};
int Queue::if_Empty() {
	if (face == nullptr && rear == nullptr) {
		return true;
	}
	return false;
}
void Queue::enqueue() {
	string i;
	int t, s, p;
	cout << "Enter Packet ID: ";
	cin >> i;
	cout << "Enter Arrival Time: ";
	cin >> t;
	cout << "Enter Size (KB): ";
	cin >> s;
	cout << "Enter Priority (1=Low, 2=Normal, 3=High): ";
	cin >> p;
	Queue* new_node = new Queue();
	new_node->id = i;
	new_node->arrival = t;
	new_node->sizekb = s;
	new_node->priority = p;
	new_node->next = nullptr;
	if (if_Empty()) {
		face = rear = new_node;
		count++;
	}
	else if (count < maxsize) {
		Queue* temp = face;
		Queue* prev = nullptr;
		while (temp != nullptr && temp->priority >= new_node->priority) {
			prev = temp;
			temp = temp->next;
		}
		if (prev == nullptr) {
			new_node->next = face;
			face = new_node;
		}
		else {
			prev->next = new_node;
			new_node->next = temp;
			if (temp == nullptr) rear = new_node;
		}
		count++;
	}
	else {
		Queue* temp = face;
		Queue* lowest = face;
		Queue* prev = nullptr;
		Queue* prevLow = nullptr;
		while (temp != nullptr) {
			if (temp->priority < lowest->priority) {
				lowest = temp;
				prevLow = prev;
			}
			temp = temp->next;
			if (prev == nullptr) prev = face;
			else prev = prev->next;
		}
		if (lowest->priority < new_node->priority) {
			if (prevLow == nullptr) {
				face = face->next;
			}
			else {
				prevLow->next = lowest->next;
				if (lowest == rear) rear = prevLow;
			}
			delete lowest;
			count--;
			Queue* t2 = face;
			Queue* pr = nullptr;
			while (t2 != nullptr && t2->priority >= new_node->priority) {
				pr = t2;
				t2 = t2->next;
			}
			if (pr == nullptr) {
				new_node->next = face;
				face = new_node;
			}
			else {
				pr->next = new_node;
				new_node->next = t2;
				if (t2 == nullptr) rear = new_node;
			}
			count++;
			cout << "Lowest priority packet dropped and new packet added.\n";
		}
		else {
			cout << "Buffer full and new packet has lower or equal priority, packet dropped.\n";
			delete new_node;
		}
	}
}
void Queue::dequeue() {
	if (face == nullptr) {
		cout << "Buffer is empty!\n";
	}
	else {
		Queue* new_node = face;
		cout << "Forwarding packet: " << face->id << " (Priority: " << face->priority << ", Size: " << face->sizekb << "KB)\n";
		face = face->next;
		if (face == nullptr) rear = nullptr;
		delete new_node;
		count--;
	}
}
void Queue::peek() {
	if (face == nullptr) {
		cout << "Buffer is empty\n";
	}
	else {
		cout << "Next packet to forward: " << face->id << " (Priority: " << face->priority << ", Size: " << face->sizekb << "KB)\n";
	}
}
void Queue::display() {
	Queue* new_node;
	new_node = face;
	cout << "All packets in Buffer are : \n";
	if (face == nullptr) {
		cout << "Buffer is Empty\n";
		return;
	}
	else {
		while (new_node != nullptr) {
			cout << "[" << new_node->id << " (P=" << new_node->priority << ",T=" << new_node->arrival << ",S=" << new_node->sizekb << "KB)]";
			if (new_node->next != nullptr) cout << " -> ";
			new_node = new_node->next;
		}
	}
	cout << endl;
}
int main() {
	Queue q;
	int choice = 1;
	while (choice != 0) {
		cout << "\nEnter what do you wanna do: ";
		cout << "\n1)Add Packet.\n2)Forward Packet.\n3)Next Packet.\n4)Check if Empty.\n5)Display Buffer.\n0)End programme.\n";
		cin >> choice;
		cout << "\n____________________________________________________________\n";
		switch (choice) {
		case 1: {
			q.enqueue();
			break;
		}
		case 2: {
			q.dequeue();
			break;
		}case 3: {
			q.peek();
			break;
		}case 4: {
			if (q.if_Empty()) {
				cout << "Buffer is empty.\n";
			}
			else {
				cout << "Buffer is not empty.\n";
			}
			break;
		}case 5: {
			q.display();
			break;
		}case 0: {
			return 0;
			break;
		}default: {
			cout << "Invalid input choice\n";
		}
		}
		cout << "\n_______________________________________________________\n";
	}
	system("Pause");
	return 0;
}
