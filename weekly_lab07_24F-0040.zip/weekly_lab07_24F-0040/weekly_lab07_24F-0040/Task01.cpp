//#include<iostream>
//#include<string>
//using namespace std;
//class Queue {
//public:
//	string data;
//	Queue* face;
//	Queue* rear;
//	Queue* next;
//	string id;
//	string name;
//	int priority;
//	Queue() {
//		face = nullptr;
//		rear = nullptr;
//		next = nullptr;
//	}
//	Queue(string d) {
//		data = d;
//	}
//	void enqueue();
//	void dequeue();
//	int if_Empty();
//	void peek();
//	void display();
//	~Queue() {
//		delete face;
//		delete rear;
//		delete next;
//	}
//};
//int Queue::if_Empty() {
//	if (face == nullptr && rear == nullptr) {
//		return true;
//	}
//	return false;
//}
//void Queue::enqueue() {
//	string i, n;
//	int p;
//	cout << "Enter id of patient: ";
//	cin >> i;
//	cin.ignore();
//	cout << "Enter name of patient: ";
//	getline(cin, n);
//	cout << "Enter priority (1=Critical, 5=Mild): ";
//	cin >> p;
//	Queue* new_node = new Queue();
//	new_node->name = n;
//	new_node->id = i;
//	new_node->priority = p;
//	new_node->next = nullptr;
//	if (if_Empty()) {
//		face = rear = new_node;
//	}
//	else {
//		Queue* temp = face;
//		Queue* prev = nullptr;
//		while (temp != nullptr && temp->priority <= new_node->priority) {
//			prev = temp;
//			temp = temp->next;
//		}
//		if (prev == nullptr) {
//			new_node->next = face;
//			face = new_node;
//		}
//		else {
//			prev->next = new_node;
//			new_node->next = temp;
//			if (temp == nullptr) rear = new_node;
//		}
//	}
//	cout << "Patient " << new_node->name << " (ID: " << new_node->id << ", Priority: " << new_node->priority << ") added.\n";
//}
//void Queue::dequeue() {
//	if (face == nullptr) {
//		cout << "Queue is empty!\n";
//	}
//	else {
//		Queue* new_node = face;
//		cout << "Treating patient: " << face->name << " (ID: " << face->id << ", Priority: " << face->priority << ")\n";
//		face = face->next;
//		if (face == nullptr) rear = nullptr;
//		delete new_node;
//	}
//}
//void Queue::peek() {
//	if (face == nullptr) {
//		cout << "Queue is empty\n";
//	}
//	else {
//		cout << "Next patient: " << face->name << " (ID: " << face->id << ", Priority: " << face->priority << ")\n";
//	}
//}
//void Queue::display() {
//	Queue* new_node;
//	new_node = face;
//	int c = 1;
//	cout << "All patients in Queue are : \n";
//	if (face == nullptr) {
//		cout << "Queue is Empty\n";
//		return;
//	}
//	else {
//		while (new_node != nullptr) {
//			cout << "[" << new_node->name << " (" << new_node->priority << ")]";
//			if (new_node->next != nullptr) cout << " -> ";
//			new_node = new_node->next;
//			c++;
//		}
//	}
//	cout << endl;
//}
//int main() {
//	Queue q;
//	int choice = 1;
//	while (choice != 0) {
//		cout << "\n--- Emergency Room Priority Queue ---\n";
//		cout << "1)Add Patient.\n2)Treat Patient.\n3)Next Patient.\n4)Check if Empty.\n5)Display Queue.\n0)End programme.\n";
//		cout << "Enter your choice: ";
//		cin >> choice;
//		cout << "\n____________________________________________________________\n";
//		switch (choice) {
//		case 1: {
//			q.enqueue();
//			break;
//		}
//		case 2: {
//			q.dequeue();
//			break;
//		}
//		case 3: {
//			q.peek();
//			break;
//		}
//		case 4: {
//			if (q.if_Empty()) {
//				cout << "Queue is empty.\n";
//			}
//			else {
//				cout << "Queue is not empty.\n";
//			}
//			break;
//		}
//		case 5: {
//			q.display();
//			break;
//		}
//		case 0: {
//			return 0;
//			break;
//		}
//		default: {
//			cout << "Invalid input choice\n";
//		}
//		}
//		cout << "\n_______________________________________________________\n";
//	}
//	system("Pause");
//	return 0;
//}
